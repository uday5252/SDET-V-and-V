package com.tests;

import com.pages.HomePage;
import com.pages.SearchPage;
import com.pages.ProfilePage;
import com.parameter.ExcelReader;
import com.parameter.PropertyReader;
import com.setup.BaseSteps;
import com.utils.Screenshots;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class Profile {
    WebDriver driver;
    HomePage home;
    SearchPage searchPage;
    ProfilePage profilePage;

    @BeforeClass
    public void init() {
        BaseSteps.setup();
        driver = BaseSteps.driver;

        driver.get(PropertyReader.getProperty("src/test/resources/PropertieFiles/home.properties", "url"));

        // Initialize all page objects with driver
        home = new HomePage(driver);
        searchPage = new SearchPage(driver);
        profilePage = new ProfilePage(driver);
    }

    @Test(priority = 1)
    public void searchBusFromExcel() {
        String from = ExcelReader.getCellValue("src/test/resources/ExcelData/Data.xlsx", 1, 0);
        String to = ExcelReader.getCellValue("src/test/resources/ExcelData/Data.xlsx", 1, 1);

        home.searchBus(from, to);                 // From HomePage
        searchPage.selectFirstBus();              // From SearchPage
        Screenshots.capture(driver, "SearchResult");
    }

    @Test(priority = 2)
    public void loginToProfile() {
        profilePage.openProfile();                // From ProfilePage
        profilePage.enterEmail("test@example.com");
        Screenshots.capture(driver, "ProfileLogin");
    }

    @AfterClass
    public void cleanup() {
        BaseSteps.teardown();
    }
}
