
package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchPage extends BasePage {
    public SearchPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//div[@class='bus-item']")
    WebElement firstBus;

    @FindBy(xpath = "//button[contains(text(),'View Seats')]")
    WebElement viewSeats;

    public void selectFirstBus() {
        firstBus.click();
        viewSeats.click();
    }
}
