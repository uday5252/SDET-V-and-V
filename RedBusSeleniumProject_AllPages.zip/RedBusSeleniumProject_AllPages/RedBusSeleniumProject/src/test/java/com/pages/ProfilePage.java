
package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProfilePage extends BasePage {
    public ProfilePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "profile_icon")
    WebElement profileIcon;

    @FindBy(id = "email")
    WebElement emailInput;

    @FindBy(id = "continueBtn")
    WebElement continueButton;

    public void openProfile() {
        profileIcon.click();
    }

    public void enterEmail(String email) {
        emailInput.sendKeys(email);
        continueButton.click();
    }
}
