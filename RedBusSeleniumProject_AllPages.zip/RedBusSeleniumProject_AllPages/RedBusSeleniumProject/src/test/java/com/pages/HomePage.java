
package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {
    public HomePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "src")
    WebElement fromInput;

    @FindBy(id = "dest")
    WebElement toInput;

    @FindBy(id = "search_btn")
    WebElement searchButton;

    public void searchBus(String from, String to) {
        fromInput.sendKeys(from);
        toInput.sendKeys(to);
        searchButton.click();
    }
}
