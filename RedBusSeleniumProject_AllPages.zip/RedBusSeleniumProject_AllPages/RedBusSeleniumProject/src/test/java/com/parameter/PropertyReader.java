
package com.parameter;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyReader {
    public static String getProperty(String path, String key) {
        try {
            FileInputStream fis = new FileInputStream(path);
            Properties prop = new Properties();
            prop.load(fis);
            return prop.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}
