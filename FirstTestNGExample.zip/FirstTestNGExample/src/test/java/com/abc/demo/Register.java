package com.abc.demo;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

//@Listeners(MyListener.class)
public class Register {

	@Test
	public void verifyRegisterWithBlankData()
	{
		System.out.println("verifyRegisterWithBlankData");
	}
	
	@Test
	public void verifyRegisterWithValidData()
	{
		System.out.println("verifyRegisterWithValidData");
	}
	
}
