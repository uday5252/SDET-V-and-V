package com.abc.demo;

import org.openqa.selenium.chrome.ChromeDriver;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class BaseTest {
    public static ThreadLocal<ChromeDriver> local1 = new ThreadLocal<>();
    public static ThreadLocal<ExtentTest> local2 = new ThreadLocal<>();
    public static ThreadLocal<ExtentReports> local3 = new ThreadLocal<>();

}
