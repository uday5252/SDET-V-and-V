package com.abc.demo;

import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

public class BaseTest {
	public static ChromeDriver driver;
	public static ExtentTest extentTest;
}
