package com.abc.demo;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

// Utility class
public class MyListener implements ITestListener {

    ExtentSparkReporter sparkReporter;
    
    @Override
    public void onStart(ITestContext context) {
        sparkReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "\\reports\\index.html");
        sparkReporter.config().setTheme(Theme.DARK);
        sparkReporter.config().setDocumentTitle("First Automation Document");
        sparkReporter.config().setReportName("Functional Testing");

        BaseTest.local3.set(new ExtentReports());
        BaseTest.local3.get().attachReporter(sparkReporter);

        BaseTest.local3.get().setSystemInfo("OS", "Windows");
        BaseTest.local3.get().setSystemInfo("Tester", "RajuRamu");
        BaseTest.local3.get().setSystemInfo("Environment", "QA");
        BaseTest.local3.get().setSystemInfo("Browser", "Chrome");
    }

    @Override
    public void onTestStart(ITestResult result) {
//        BaseTest.extentTest = extentReports.createTest(result.getMethod().getMethodName());
    	BaseTest.local2.set(BaseTest.local3.get()
				.createTest(result.getMethod().getMethodName()));
        BaseTest.local2.get().log(Status.INFO, "Test started"+ result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
//    	BaseTest.extentTest.log(Status.PASS, "Test passed");
    	BaseTest.local2.get().log(Status.PASS, "Test finished"+ result.getMethod().getMethodName());

    }

    @Override
    public void onTestFailure(ITestResult result) {
    	BaseTest.local2.get().log(Status.FAIL, "Test failed"+ result.getMethod().getMethodName());

//    	BaseTest.extentTest.log(Status.FAIL, "Test failed: " + result.getMethod().getMethodName());


        // Capture screenshot
        try {
            File src = ((TakesScreenshot)BaseTest.local1.get()).getScreenshotAs(OutputType.FILE);
            String path = System.getProperty("user.dir") + "\\screenshots\\" + result.getMethod().getMethodName() + ".png";
            FileUtils.copyFile(src, new File(path));
            BaseTest.local2.get().addScreenCaptureFromPath(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
    	BaseTest.local2.get().log(Status.SKIP, "Test skipped");
    }

    @Override
    public void onFinish(ITestContext context) {
    	BaseTest.local3.get().flush();
    }
}
