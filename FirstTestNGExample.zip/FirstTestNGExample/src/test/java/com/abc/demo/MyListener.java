package com.abc.demo;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class MyListener implements ITestListener {
	
	ExtentSparkReporter sparkReporter;
	ExtentReports extentReports;
	ExtentTest extentTest;

	@Override
	public void onTestStart(ITestResult result) {
		extentTest.log(Status.INFO, 
				"Test Case Execution started! "+result.getMethod().getMethodName());
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		extentTest = extentReports.createTest(result.getMethod().getMethodName());
		extentTest.log(Status.PASS, 
				"Test Case Execution finished ! "+result.getMethod().getMethodName());

		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		extentTest = extentReports.createTest(result.getMethod().getMethodName());
		extentTest.log(Status.FAIL, 
				"Test Case Execution failed! "+result.getMethod().getMethodName());

	}

	@Override
	public void onTestSkipped(ITestResult result) {
		extentTest = extentReports.createTest(result.getMethod().getMethodName());
		extentTest.log(Status.SKIP, 
				"Test Case Execution skipped! "+result.getMethod().getMethodName());

	}

	@Override
	public void onStart(ITestContext context) {
		
		sparkReporter = new ExtentSparkReporter(System.getProperty("user.dir")+"\\reports\\index.html");
		sparkReporter.config().setTheme(Theme.DARK);
		sparkReporter.config().setDocumentTitle("First Automation Document");
		sparkReporter.config().setReportName("Functional Testing");
		
		extentReports = new ExtentReports();
		extentReports.attachReporter(sparkReporter);
		extentReports.setSystemInfo("os", "windows");
		extentReports.setSystemInfo("Tester Name", "RajuRamu");
		extentReports.setSystemInfo("Environment", "QA");
		extentReports.setSystemInfo("Browser Name", "Chrome");
		
		
	}

	@Override
	public void onFinish(ITestContext context) {
		System.out.println("Test Case Execution finished!");
		extentReports.flush();
	}

}
