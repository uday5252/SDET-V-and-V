package com.abc.demo;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

// Utility class
public class MyListener implements ITestListener {

    ExtentSparkReporter sparkReporter;
    ExtentReports extentReports;
    
    

    @Override
    public void onStart(ITestContext context) {
        sparkReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "\\reports\\index.html");
        sparkReporter.config().setTheme(Theme.DARK);
        sparkReporter.config().setDocumentTitle("First Automation Document");
        sparkReporter.config().setReportName("Functional Testing");

        extentReports = new ExtentReports();
        extentReports.attachReporter(sparkReporter);

        extentReports.setSystemInfo("OS", "Windows");
        extentReports.setSystemInfo("Tester", "RajuRamu");
        extentReports.setSystemInfo("Environment", "QA");
        extentReports.setSystemInfo("Browser", "Chrome");
    }

    @Override
    public void onTestStart(ITestResult result) {
        BaseTest.extentTest = extentReports.createTest(result.getMethod().getMethodName());
        BaseTest.extentTest.log(Status.INFO, "Test started"+ result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        extentTest.log(Status.PASS, "Test passed");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        extentTest.log(Status.FAIL, "Test failed: " + result.getMethod().getMethodName());


        // Capture screenshot
        try {
            File src = ((TakesScreenshot)BaseTest.driver).getScreenshotAs(OutputType.FILE);
            String path = System.getProperty("user.dir") + "\\screenshots\\" + result.getMethod().getMethodName() + ".png";
            FileUtils.copyFile(src, new File(path));
            extentTest.addScreenCaptureFromPath(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        extentTest.log(Status.SKIP, "Test skipped");
    }

    @Override
    public void onFinish(ITestContext context) {
        extentReports.flush();
    }
}
