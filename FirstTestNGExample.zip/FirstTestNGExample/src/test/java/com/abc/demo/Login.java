package com.abc.demo;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

//@Listeners(MyListener.class)
public class Login {
	
	@Test(priority = 56, groups = {"smoke", "component"})
	public void verifyLoginWithValidData()
	{
		System.out.println("verifyLoginWithValidData");
	}
	
	@Test(priority = 55, invocationCount = 5)
	public void verifyLoginWithInvalidData()
	{
		System.out.println("verifyLoginWithInalidData");
	}
	
//	@Test(priority = 100, enabled = false)
	@Test(priority = 100, groups = {"component"})
	public void verifyLoginWithBlankData()
	{
		System.out.println("verifyLoginWithBlankData");
	}
	
	@Test(groups = {"smoke"})
	public void valiLogin()
	{
		Assert.fail("Some problem occured!");
//		System.out.println("Verify valid login");
	}
	
	@Test(dependsOnMethods = "valiLogin")
	public void validateHomePageTitle()
	{
		System.out.println("Verify title");
	}

}
