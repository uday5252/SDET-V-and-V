package com.abc.demo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

@Listeners(MyListener.class)
public class Login extends BaseTest {
	
	@Test
	public void valiLogin()
	{
//		BaseTest.local2.set(new ExtentTest());
		
		
		BaseTest.local1.set(new ChromeDriver());
		
	
		BaseTest.local2.get().log(Status.INFO, "Applying implicit wait");
		BaseTest.local1.get().manage().timeouts()
		.implicitlyWait(Duration.ofSeconds(10));
		
		
		BaseTest.local2.get().log(Status.INFO, "Maximizing the browser");
		BaseTest.local1.get().manage().window().maximize();
		
		BaseTest.local2.get().log(Status.INFO, "Navigating to Facebook");
		BaseTest.local1.get().get("https://www.facebook.com");
		
		

		BaseTest.local2.get().log(Status.WARNING, "Email webelement"
				+ " is not properly alligned!");
		
		BaseTest.local2.get().log(Status.INFO, "Entering the email");
		BaseTest.local1.get().findElement(By.id("email"))
		.sendKeys("Raju123@gmail.com");
		
		BaseTest.local2.get().log(Status.INFO, "Entering the password");
		BaseTest.local1.get().findElement(By.id("password"))
		.sendKeys("Raju123");
		
		BaseTest.local2.get().log(Status.INFO, "Closing the browser");
		BaseTest.local1.get().quit();

	}
	
	@Test
	public void InvaliLogin()
	{
		BaseTest.local2.get().log(Status.INFO, "Opening the browser");
		BaseTest.local1.set(new ChromeDriver());
		
		
		BaseTest.local2.get().log(Status.INFO, "Applying implicit wait");
		BaseTest.local1.get().manage().timeouts()
		.implicitlyWait(Duration.ofSeconds(10));
		
		
		BaseTest.local2.get().log(Status.INFO, "Maximizing the browser");
		BaseTest.local1.get().manage().window().maximize();
		
		BaseTest.local2.get().log(Status.INFO, "Navigating to Facebook");
		BaseTest.local1.get().get("https://www.facebook.com");
		
		

		BaseTest.local2.get().log(Status.WARNING, "Email webelement"
				+ " is not properly alligned!");
		
		BaseTest.local2.get().log(Status.INFO, "Entering the email");
		BaseTest.local1.get().findElement(By.id("email"))
		.sendKeys("Raju123@gmail.com");
		
		BaseTest.local2.get().log(Status.INFO, "Entering the password");
		BaseTest.local1.get().findElement(By.id("password"))
		.sendKeys("Raju123");
		
		BaseTest.local2.get().log(Status.INFO, "Closing the browser");
		BaseTest.local1.get().quit();

	}
}
