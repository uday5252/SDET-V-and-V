package com.abc.demo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;

@Listeners(MyListener.class)
public class Login extends BaseTest {

	@BeforeMethod
	public void beforeMethod() {
	    // Initialize the ChromeDriver for the current thread
	    ChromeDriver driver = new ChromeDriver();
	    local1.set(driver);

	    local3.set(new ExtentReports());
	    }
	

	@AfterMethod
	public void afterMethod() {
	    // Clean up resources
	        local1.get().quit();
	        local3.get().flush();
	    }
	


    @Test
    public void valiLogin() {
        BaseTest.local2.get().log(Status.INFO, "Applying implicit wait");
        BaseTest.local1.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        BaseTest.local2.get().log(Status.INFO, "Maximizing the browser");
        BaseTest.local1.get().manage().window().maximize();

        BaseTest.local2.get().log(Status.INFO, "Navigating to Facebook");
        BaseTest.local1.get().get("https://www.facebook.com");

        BaseTest.local2.get().log(Status.WARNING, "Email webelement is not properly aligned!");
        BaseTest.local2.get().log(Status.INFO, "Entering the email");
        BaseTest.local1.get().findElement(By.id("email")).sendKeys("Raju123@gmail.com");

        BaseTest.local2.get().log(Status.INFO, "Entering the password");
        BaseTest.local1.get().findElement(By.id("password")).sendKeys("Raju123");
    }

    @Test
    public void InvaliLogin() {
        BaseTest.local2.get().log(Status.INFO, "Opening the browser");
        BaseTest.local2.get().log(Status.INFO, "Applying implicit wait");
        BaseTest.local1.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        BaseTest.local2.get().log(Status.INFO, "Maximizing the browser");
        BaseTest.local1.get().manage().window().maximize();

        BaseTest.local2.get().log(Status.INFO, "Navigating to Facebook");
        BaseTest.local1.get().get("https://www.facebook.com");

        BaseTest.local2.get().log(Status.WARNING, "Email webelement is not properly aligned!");
        BaseTest.local2.get().log(Status.INFO, "Entering the email");
        BaseTest.local1.get().findElement(By.id("email")).sendKeys("Raju123@gmail.com");

        BaseTest.local2.get().log(Status.INFO, "Entering the password");
        BaseTest.local1.get().findElement(By.id("password")).sendKeys("Raju123");
    }
}
