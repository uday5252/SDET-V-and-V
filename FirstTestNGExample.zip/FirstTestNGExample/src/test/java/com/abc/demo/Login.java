package com.abc.demo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

//@Listeners(MyListener.class)
public class Login extends BaseTest {
	
	@Test
	public void valiLogin()
	{
		extentTest.log(Status.INFO, "Opening the browser");
		driver = new ChromeDriver();
		
		extentTest.log(Status.INFO, "Applying implicit wait");
		driver.manage().timeouts()
		.implicitlyWait(Duration.ofSeconds(10));
		
		
		extentTest.log(Status.INFO, "Maximizing the browser");
		driver.manage().window().maximize();
		
		extentTest.log(Status.INFO, "Navigating to Facebook");
		driver.get("https://www.facebook.com");
		
		

		extentTest.log(Status.WARNING, "Email webelement"
				+ " is not properly alligned!");
		
		extentTest.log(Status.INFO, "Entering the email");
		driver.findElement(By.id("email"))
		.sendKeys("Raju123@gmail.com");
		
		extentTest.log(Status.INFO, "Entering the password");
		driver.findElement(By.id("password"))
		.sendKeys("Raju123");
		
		extentTest.log(Status.INFO, "Closing the browser");
		driver.quit();

	}
}
