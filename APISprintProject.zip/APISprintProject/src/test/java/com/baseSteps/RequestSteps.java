package com.baseSteps;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

///objects ==> GET all objects
//given() ==> will create a new request

public class RequestSteps extends BaseSteps {
	
	public static Response getAPI()
	{
//		I want to send GET request
		RequestSpecification request = RestAssured.given();
		return request.get("/objects");
	}
	
	public static Response postAPI()
	{
//		I want to send GET request
		RequestSpecification request = RestAssured.given();
		return request
				.header("Content-Type", "application/json")
			    .body("""
			        {
			           "name": "Samiksha",
			           "data": {
			              "year": 2018,
			              "price": 3000.99,
			              "CPU model": "Intel Core i9",
			              "Hard disk size": "2 TB"
			           }
			        }
			        """)
			    .post("/objects");

	}
}
