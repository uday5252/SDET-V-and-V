package com.test;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.baseSteps.BaseSteps;
import com.baseSteps.RequestSteps;

import io.restassured.response.Response;

public class TestFile {

	@BeforeClass
	public void initiliaze() throws IOException
	{
		BaseSteps.setup();
	}
	
	@Test(priority = 1, enabled = false)
	public void callGetAPI()
	{
		Response response = 
				RequestSteps.getAPI();
		System.out.println(response.getBody().asPrettyString());
	}
	
	@Test(priority = 0)
	public void callPostAPI()
	{
		Response response = 
				RequestSteps.postAPI();
		System.out.println(response.getBody().asPrettyString());
	}
}
