package com.abc.demo.CrossBrowser;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



public class CrossBrowserTesting {
	
	WebDriver driver;
	
	@Parameters({"data"})
	@BeforeTest
	public void collectData(String broswer)
	{
		if(broswer.equals("chrome"))
		{
			driver = new ChromeDriver();
		}
		else if(broswer.equals("firefox"))
		{
			driver = new FirefoxDriver();
		}
		
	}
	
	
	@Test
	public void login()
	{
		
			driver.get("https://www.facebook.com");
			
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	        driver.manage().window().maximize();

	        driver.get("https://www.facebook.com");

	        driver.findElement(By.id("email")).sendKeys("Raju123@gmail.com");

	        driver.findElement(By.id("pass")).sendKeys("Raju123");

		}
		
		    }

	


